<script>
  import Counter from './lib/Counter.svelte'
  import Playlist from './playlist.svelte';
  import Calendar from './calendar.svelte';
  import { journalData } from './stores/journal.js';
  import { get } from 'svelte/store';
  import { onMount } from 'svelte';
	
  //https://svelte.dev/playground/f6514d9b90b344a1b1bcc14814470eee?version=5.38.6#H4sIAAAAAAAAE42SvY7bMBCEX2WxzTW2aCdIo5OF5B2CpAhTrKm1SBz_QK7s-Ay_e6CTL77CRdhx-O3MkOAFIwXGFr_WI5kXGrkqT6_nNRlxKeIKD85zxfbXBeWcZ3IWcPU-9y3nph7Zy6ztqfIj3aQoHKVii101xWXpddTiQk5FYM6DQ0kBnh63UPuSTpXL07OOnbobxM5u-5_sTQoMkkAsw4cxeDfrlN32Ona5_-GqE-gIbOHDTqMVybVVanRip31jUlAPG2jsF6RT1M9RhWl4yxuSmQJHoRnrVF56ZTCeat1pLEzen9c-xXGdqdBYKFuNvY4AAN-tq-AqECwczBz845qm0XdTF8ZlaqrczuWW3UBC61rMh-tkZ-oUmmyTpKo-bTbq82ajceHJy05jTYHFujhCoTikoBHULeZQKPB_JhV28hq5NCTv_uLE805jOMOJ99UJa-w7tdguEVXOnm9P0Dx8Ibgsp_Oy7EYrLWy_bI72-a7vybyMJU1xWJvkU2nBz-DeT3yjrm__5RaGKxT-I9hKmfj6e4VCzp9cHLA9kK98_QudezgADAMAAA==
  //https://svelte.dev/playground/417334165e9247b4b64c94fe7547e257?version=5.38.6#H4sIAAAAAAAAE41UXW_aMBT9K1eeuoJGS2jVPaTAhFZtazW2SUXqQ90Hk1zAarAj-xrKUv775CR8NtD5Jck55347N2NKTJGF7AcmiYa5NknMGmwkE7QsfMwYLVJPe4A1VuJemp7bGSbksaGwWIVHWhEqsixkbRsZmVKXK06c5DTVhiADrfraKYIljIyewmlhenqdy3JpswnfkUiqMQwmCF-dMagIbgQhfISBnCL0VAz3peaWuAIASJAgKrRemus6oHCeW9bqWxHKHGq1OnS6kBUgp0grSyAVoZmJBDpgkW7Lr30tp_djEadlA1pBEORACRkkZxS89ZegMOtwqyy2XJVvy1UlvuiRUxFJrWCM9ID4fCMWtaju3UJ5fFtisbA_pSXowOOG8Yeze6diseCssU_09QFi4NBWMw8Yq0PcYOLMAeqbkdXEvSBncmrDPF1v3stWrsp7jM7HSL4F9ZVq-bZNfa1oUtGkqccPtulOKCdMZfY4NAeovjDRpALvpUYmlfoqL3dOYSWcVKl7buwsVTUTU8LpEE0F9zsiXc380rNDRjcYldTR6Wz6Wsyn6P-xCeX_0O6ASl_lgMtf7ID5D-3MEXNP21odTqB1Aa-v0Lo4clekckdzKQTeXRtaAXwBzgLO4NM-G-4BR0KikbHE6X9U0PYV-JC9PmcQAmd_-pxtXLebmxWs2pYWCXYL8tzvaSEVmu0YQxE9j412Kj6LdKJNCB9G-dka6lCbGM2ZEbF0NoSr9GWLHGlFZ1b-xRBalzvMBOV4QiFcXezAcxnTJITPwckm6zLDWBCekV-s2V6A-cpXEOzUWtbHVTuWM4gSYW2Hs3WlnJXF79DrMGs6l9hUqB0NZ91se8fuLv_6uXVDS6YWNOCyvoRss2feFxbXfU-3bDd9DgdzKlPO1vd93z7Mtu7vPlkkuL5pR2O3m7GcdX2H_ZM1GOELsZCMw-VTg5GQyVyqmIUjkVhc_gP3GK1SXQgAAA==
  let currentDateTime = new Date();

  onMount(() => {
    const interval = setInterval(() => {
      currentDateTime = new Date();
    }, 1000);

    return () => {
      clearInterval(interval);
    };
  });

  function getWeekDay(c) {
      let daysList = [
          "Sunday",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday"
      ];
      return daysList[c.getDay()];
  }
  function getMonth(c) {
      let monthsList = [
          "January",
          "February",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "September",
          "October",
          "November",
          "December"
      ];
      return monthsList[c.getMonth()];
  }
  function getDate(c) {
      return c.getDate();
  }
  function getHour(c) {
      return c.getHours() % 12 || 12;
  }
  function getMinute(c) {
      return c.getMinutes() < 10 ? "0" + c.getMinutes() : c.getMinutes();
  }
  function getMeridiem(c) {
      return c.getHours() < 12 ? "AM" : "PM";
  }
  let genre = $state(1);
  let name = $state('enter song here');

  const genreTypes = {
    1: 'Baroque (1600-1750 apx)',
    2: 'Classical (1750-1820 apx)',
    3: 'Romantic (1820-1900 apx)',
    4: 'Modern (1900-Present)'
  };


  function handleInput(event) {
      name.set(event.target.value); 
  }
  const images = [
    {
      src: '/images/eugeneTchai.jpg',
      link: 'https://youtu.be/8n_j3cC_Is8?si=MhjfWbFjglaGvAp-'
    },
    {
      src: '/images/minkusBayadere.jpeg',
      link: 'https://youtu.be/Qsw8fD4z5SI?si=SyU48wC9RDvVaEDc'
    },
    {
      src: '/images/rachPiano.jpg',
      link: 'https://www.youtube.com/playlist?list=PLBCTw1ttb2H-ySE_43qkgWd-MsUKspuC9'
    },
    {
      src: '/images/terzzettoDvorak.jpg',
      link: 'https://youtu.be/jsdC5nPoNVk?si=pfSniGK3KTYzWP0o'
    },
    {
      src:'/images/faurePellas.jpg',
      link: 'https://youtu.be/qroD6PeafgA?si=9g4GMJy778Z8LnKT'
    },
    {
      src:'/images/straussJuan.jpeg',
      link: 'https://youtu.be/XG4uBRBMdzY?si=yqaALH8n24Bwqhgo'
    }
  ];

  //creating the database 
  let today = $state(new Date());
  let dateIndex = $derived(() => {
    const local = new Date(today.getTime() - today.getTimezoneOffset() * 60000);
    return local.toISOString().split('T')[0];
  });

  let entry = $state({
    decade: '',
    genre: '',
    today: '',
    tommorow: '',
    notes: '',
    photos: [],
    calendarEvents: [],
    userEvents:[]
  });

  //auto save?
  $effect(() => {
    const saved = get(journalData)[dateIndex()];
    entry = saved
      ? { ...saved }
      : {
          decade: '',
          genre: '',
          today: '',
          tommorow: '',
          notes: '',
          photos: [],
          calendarEvents: [],
          userEvents: []
        };
  });

  //manual
  function saveEntry() {
    journalData.update(data => {
      data[dateIndex()] = entry;
      return data;
    });
  }

  function changeDate(offset) {
    saveEntry();
    today.setDate(today.getDate() + offset);
    today = new Date(today);
  }

  function handleDateInput(e) {
    saveEntry();
    today = new Date(e.target.value);
  }


  //add photo
  function handlePhotoUpload(event) {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      entry.photos = [...entry.photos, {
        id: crypto.randomUUID(),
        src: reader.result,
        title: ''
      }];
    };
    reader.readAsDataURL(file);
  }

  //add light and dark modde
  let theme = $state('light');

  let entryCount = $derived(() => {
    const data = get(journalData);
    return Object.values(data).filter(e => e.notes && e.notes.trim().length > 0).length;
  });

  //calendar mod
  let selectedOrch = $state('CSO');

</script>

<main class={theme}>
  <p>
    <button class="theme-toggle" onclick={() => theme = theme === 'light' ? 'dark' : 'light'}>
    {theme === 'light' ? 'Dark Mode' : 'Light Mode'}
</button>
  </p>
  <h1>
    Chopin Chronicle
  </h1>

  <h2>
    Welcome Back Rania! It is currently
  {getWeekDay(currentDateTime)}, {getMonth(currentDateTime)} {getDate(currentDateTime)} — 
  {getHour(currentDateTime)}:{getMinute(currentDateTime)} {getMeridiem(currentDateTime)}
  </h2>

  <h2>
    _____________________________
  </h2>


  <h3>
    Your Recomended Albums 
    <div class="images"> 
      {#each images as album} 
      <a href={album.link} target="_blank"> 
        <img src={album.src} alt="Composer album" 
        /> 
      </a> 
      {/each} 
    </div> 
  </h3>

  <h2><i>Daily Mood Playlist</i></h2>
  <Playlist />

  <p>
     _________________________________________________________________________________________________________________________________________________
  </p>

  <h4>
    <label> Number of Performances: 
    <input 
    placeholder="Wish number to see"
    oninput={handleInput} 
    />
  </label>
  </h4>
  <h4>
    <label for="orchestraSelect">View Calendar:</label>
    <select id="orchestraSelect" bind:value={selectedOrch}>
      <option value="CSO">Cincinnati Symphony Orchestra</option>
      <option value="LSO">Lousville Symphony Orchestra</option>
      <option value="KYSO">Kentucky Symphonic Orchestra</option>
    </select>
  </h4>
  
  <h2>Latest Symphony Performance</h2>
    <Calendar bind:today {saveEntry} bind:selectedOrch />

  <div class="container">
    <div class="nav-buttons">
      <button onclick={() => changeDate(-1)}>← Previous</button>
      <input type="date" value={dateIndex()} onchange={handleDateInput} />
      <button onclick={() => changeDate(1)}>Next →</button>
    </div>

    <label for="userJournal"><h3>Journal Notes</h3>
    </label>
    <textarea
      placeholder="notes"
      id="userJournal"
      name="journal"
      rows="6"
      cols="100"
      bind:value={entry.notes}
    ></textarea>

    <div class="genreSelect">
      {#each [1, 2, 3, 4] as number}
        <label>
          <input
            type="radio"
            name="genre"
            value={number}
            bind:group={entry.genre}
          />
          {genreTypes[number]}
        </label>
      {/each}
    </div>

    
  </div>
  
  <!-- maybe allow the user to ignore fields if they do not want to log it for the day? or possibly allow the chantge the element ie instead of concert then practice?
   -->
  <!-- most likely remove the add feature, maybe switch to add additional calendar feature? might be better to add other symphonies-->

  <h2>
         _____________________________      
  </h2>

  <h2>
    Days Active: 12
  </h2>
  <h2>
    Days since creation: 17
  </h2>

  <h2>
    <label> Listen of the Day: <input 
      placeholder="Enter Song Here"
      oninput={handleInput} 
      bind:value={entry.today}
      />
    </label>
  </h2>
  <h2>
    <label> For Next Time: 
        <input 
        placeholder="Enter Song Here"
        oninput={handleInput} 
        bind:value={entry.tommorow}
        />
    </label>
  </h2>
  <h2>
    Total Journal Entries: {entryCount()}
  </h2>

  <h2>
    <button class="save-button" onclick={saveEntry}>Save Entry</button>
  </h2>
  


</main>
<style>
  .images {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 1.5rem;
    padding: 1rem;
  }

  .images img {
    width: 180px;
    height: 180px;
    object-fit: cover;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    cursor: pointer;
  }

  .images img:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.25);
  }
  
  .nav-buttons {
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
  }

  .nav-buttons button {
    padding: 0.4rem 0.8rem;
    background: #ddd6e1;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }

  .container {
    margin-top: 2rem;
    padding: 1rem;
    border-top: 1px solid #ddd6e1;
  }

  .save-button {
    background-color: #ddd6e1;
    color: white;
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    font-size: 1rem;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
    transition: transform 0.2s ease, background-color 0.3s ease;
  }

  .save-button:hover {
    background-color: #ddd6e1;
    transform: scale(1.03);
  }

  .theme-toggle {
    background-color: #ddd6e1;
    color: white;
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    font-size: 1rem;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
    transition: transform 0.2s ease, background-color 0.3s ease;
  }

  .theme-toggle:hover {
    background-color: #ddd6e1;
    transform: scale(1.03);
  }

  main.light {
  background-color: #dfc6c7;
  color: #333;
  }

  main.dark {
    background-color: #1e1e1e;
    color: #f0f0f0;
  }

  main.dark .theme-toggle {
    background: #444;
    color: #f0f0f0;
  }
  


  </style>
