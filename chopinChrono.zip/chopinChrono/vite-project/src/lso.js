// lsoEvents.js
export const lsoEvents = [
  {
    title: "Rachmaninoff Piano Concerto No. 3",
    program:"Star Spangled Banner,  On the Bride of the Eternal, The Glass Bead Game, Piano Concerto No.3 in D Minor" ,
    composer: "Smith/Key, Theofanidis, Baker, Rachmaninoff",
    date: "2025-10-04",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "Performed by guest Pianist Tony Siqi Yun"
  },
  {
    title: "Beethoven Pastoral Symphony",
    program:"Ev'ry Time I Blinkm A HIdden Sun Rises, Violin Concerto No.2 'Pulse', Symphony NO.6 in F Major OP.68 'Pastoral'" ,
    composer: "Green, Komschiles, Bielawa, van Beethoven",
    date: "2025-10-24",
    time: "11:00",
    location: "The Kentucky Centre",
    description: "Guest Violinist Tessa Lark"
  },
  {
    title: "Beethoven Pastoral Symphony",
    program:"Ev'ry Time I Blinkm A HIdden Sun Rises, Violin Concerto No.2 'Pulse', Symphony NO.6 in F Major OP.68 'Pastoral'" ,
    composer: "Green, Komschiles, Bielawa, van Beethoven",
    date: "2025-10-25",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "Guest Violinist Tessa Lark"
  },
  {
    title: "Yuja Wang & Teddy Abrams Return",
    program:"Hungarian Rhapsody No. 2 In C Minor, Pinao Concerto, Concerto for Orchestra" ,
    composer: "Liszt, Ligeti, Bartók",
    date: "2025-11-21",
    time: "11:00",
    location: "The Kentucky Centre",
    description: "World Renoun Pianist Yuja Wang returns to Lousiville with the sounds of Hungary"
  },
  {
    title: "Yuja Wang & Teddy Abrams Return",
    program:"Hungarian Rhapsody No. 2 In C Minor, Pinao Concerto, Concerto for Orchestra" ,
    composer: "Liszt, Ligeti, Bartók",
    date: "2025-11-22",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "World Renoun Pianist Yuja Wang returns to Lousiville with the sounds of Hungary"
  },
  {
    title: "Teddy Conducts Mahler's Ninth",
    program:"Symphony No. 9 in D Minor" ,
    composer: "Gustav Mahler",
    date: "2026-01-16",
    time: "11:00",
    location: "The Kentucky Centre",
    description: "Mahler's last completed symphony reflecting on life, love, and mortality"
  },
  {
    title: "Teddy Conducts Mahler's Ninth",
    program:"Symphony No. 9 in D Minor" ,
    composer: "Gustav Mahler",
    date: "2026-01-17",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "Mahler's last completed symphony reflecting on life, love, and mortality"
  },
  {
    title: "Sounds of a New Nation",
    program:"Piano Concerto No.9 L.271, New England Holidays" ,
    composer: "Mozart and Charles Ives",
    date: "2026-02-20",
    time: "11:00",
    location: "The Kentucky Centre",
    description: "Bringing to life anthems, hymns, and symphonic works of early America"
  },
  {
    title: "Sounds of a New Nation",
    program:"Chester, New England Triptych, Piano Concerto No.9 K. 271, New England Holidays" ,
    composer: "Billings, Schuman, Mozard, and Ives",
    date: "2026-02-21",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "Bringing to life anthems, hymns, and symphonic works of early America"
  },
  {
    title: "Eric Whitacre in Concert",
    program:"Prelude in C, The Pacific Has no Memory, The Seal Lullaby, October, Equus, Deep Field" ,
    composer: "Eric Whitacre",
    date: "2026-03-07",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "Featuring Anne Akiko Meyers and the Louisville Chamber Chior Grammy Winning Eric Whitare leads LSO"
  },
  {
    title: "Copland's Appalachian Spring",
    program:"New Work LOCC World Premire, Silicon Hymnal, Appalachian Spring" ,
    composer: "Komschlies, Bates, Copland",
    date: "2026-04-11",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "The celebration of the American sound and movement with the Louisville Ballet"
  },
  {
    title: "Rapsody in Blude",
    program:"World Premiere, Rhapsody in Blue, An Atals of Deep Time" ,
    composer: "Anthony Green, Gershwin, Luther Adams",
    date: "2026-04-24",
    time: "11:00",
    location: "The Kentucky Centre",
    description: "100 years later and Gershwin inspires many as Green releases a new piece during his tenture"
  },
  {
    title: "Rapsody in Blude",
    program:"World Premiere, Rhapsody in Blue, An Atals of Deep Time" ,
    composer: "Anthony Green, Gershwin, Luther Adams",
    date: "2026-04-25",
    time: "19:30",
    location: "The Kentucky Centre",
    description: "100 years later and Gershwin inspires many as Green releases a new piece during his tenture"
  },
  
];