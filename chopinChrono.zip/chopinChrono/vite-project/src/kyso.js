// kysoEvents.js
export const kysoEvents = [
    {
    title: "Back in My Day",
    program:"Hornpipe from Water Music, Finale to Symphony No 45, Symphony No. 5, Prelude to Act III of Lohengrin, Violin Concerto, Finale to Firebird, Hoe-Down from Rodeo, Pirates of the Caribbean:Curse of the Black Peral, The Wide Reciever NBC Sunday Night Football Theme" ,
    composer: "Handel, Haydn, Beethoven, Wagner, Bruch, Stravinsky, Copland, Badelt/Zimmer, Williams",
    date: "2025-10-21",
    time: "10:00",
    location: "Seven Hills Church",
    description: "A 300-year distory of the orchestra and western music dating back to the 1700s"
  },
  {
    title: "Back in My Day",
    program:"Hornpipe from Water Music, Finale to Symphony No 45, Symphony No. 5, Prelude to Act III of Lohengrin, Violin Concerto, Finale to Firebird, Hoe-Down from Rodeo, Pirates of the Caribbean:Curse of the Black Peral, The Wide Reciever NBC Sunday Night Football Theme" ,
    composer: "Handel, Haydn, Beethoven, Wagner, Bruch, Stravinsky, Copland, Badelt/Zimmer, Williams",
    date: "2025-10-22",
    time: "10:00",
    location: "Seven Hills Church",
    description: "A 300-year distory of the orchestra and western music dating back to the 1700s"
  },
  {
    title: "Nosferatu",
    program:"Nosferatu" ,
    composer: "Heinrich Marschner",
    date: "2025-10-31",
    time: "19:30",
    location: "NKU Greaves Concert Hall",
    description: "Join the KYSO on Halloween to play long the slient-film Nosferatu"
  },
  {
    title: "Missa Solemnis",
    program:"Missa Solemnis Op. 123" ,
    composer: "Ludwig van Beethoven",
    date: "2025-11-22",
    time: "19:30",
    location: "St. Peter in Chains Cathedral Basilica",
    description: "One of Beethoven's greatest pieces that are never heard"
  },
  {
    title: "Gallery Fantastique",
    program:"Flowers from Vincent, Symphony on the Art of Andy Warhol, Pictures at Exhibition" ,
    composer: "Andrew Strawn, Michael Daugherty, Mussorgsky",
    date: "2026-02-07",
    time: "19:30",
    location: "NKU Greaves Concert Hall",
    description: "Art of Van Gogh, Warhol, and Hartmann will be projected while the Orchestra performs"
  },
  {
    title: "Art and Anxiety",
    program:"Larghetto and Caconne from Don Juan, Symphony in B minor, Symphony for Strings in D Minor, Symphony in G Minor, Symphony No. 39 in G Minor" ,
    composer: "Gluck, Carl Bach, Boccherini, Koželuch, Haydn",
    date: "2026-03-21",
    time: "19:30",
    location: "NKU Greaves Concert Hall",
    description: "Music focusing on the Euopean and American wars from 1760s and 70s"
  },
  {
    title: "Parsley, Sage, Rosemary and Thyme",
    program:"Kodachrome, The Boxer, I only Have Eyes for You, Homeward Bound, Me and Julio, Scarborough Fair, 50 Ways to Leave Your Lover, The Same Old Tears on a New Background, Bridge Over Troubled Water, The Sound of Silence" ,
    composer: "Mrs. Robinson, Disney Girls, Slip Sliding Away, You Can Call me Al, Breakaway, Cecilia, I Believe, Still Crazy, My Little Town ",
    date: "2026-05-15",
    time: "19:30",
    location: "NKU Greaves Concert Hall",
    description: "Supply the Local Hits of 1960's through the 80's!"
  }
]