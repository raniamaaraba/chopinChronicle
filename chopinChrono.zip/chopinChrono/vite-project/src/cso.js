// csoEvents.js
export const csoEvents = [
  {
    title: "From Beethoven to Hidemith",
    program:"Oktett, Suite for Two Violins and Piano, String Quartet No. 6" ,
    composer: "Hidemith, Moszkowski, and Beethoven",
    date: "2025-09-16",
    time: "19:30",
    location: "Music Hall",
    description: "Three composers--three different centuries of music"
  },
  {
    title: "The Voice of Whitney: A Symphonic Celebration",
    program:"",
    composer: "Whitney Houston",
    date: "2025-09-20",
    time: "19:30",
    location: "Music Hall",
    description: "Houstons' classics performed with accompanining never-seen-before footage"
  },
  {
    title: "The Voice of Whitney: A Symphonic Celebration",
    program: "",
    composer: "Whitney Houston",
    date: "2025-09-21",
    time: "14:00",
    location: "Music Hall",
    description: "Houstons' classics performed with accompanining never-seen-before footage"
  },
  {
    title: "Distant Worlds:music from FINAL FANTASY",
    program:"",
    composer: "Uematsu, Hamauzu, Soken, Shiomura",
    date: "2025-09-27",
    time: "19:30",
    location: "Music Hall",
    description: "Arnie Roth will be conducting both CPO and the May Festival Chorus in the classic works from FINAL FANTASY"
  },
  {
    title: "Distant Worlds:music from FINAL FANTASY",
    program:"",
    composer: "Uematsu, Hamauzu, Soken, Shiomura",
    date: "2025-09-28",
    time: "14:00",
    location: "Music Hall",
    description: "Arnie Roth will be conducting both CPO and the May Festival Chorus in the classic works from FINAL FANTASY"
  },
  {
    title: "Gershwin & Strauss: Cristian Mǎcelaru's Debut",
    program: "Abstractions, Piano Concerto in F Major, Der Rosenkavalier Suite",
    composer: "Clyne, Gershwin, Strauss",
    date: "2025-10-03",
    time: "19:30",
    location: "Music Hall",
    description: "Welcome condutor Cristian Mǎcelaru conducting the CSO and pianist Hélène Grimaud"
  },
  {
    title: "Gershwin & Strauss: Cristian Mǎcelaru's Debut",
    program: "Abstractions, Piano Concerto in F Major, Der Rosenkavalier Suite",
    composer: "Clyne, Gershwin, Strauss",
    date: "2025-10-04",
    time: "19:30",
    location: "Music Hall",
    description: "Welcome condutor Cristian Mǎcelaru conducting the CSO and pianist Hélène Grimaud"
  },
  {
    title: "Dame Jane Conducts Mozart",
    program: "Overature to Lucio Silla, Sinfonia Concertante, Symphony No. 41: Jupiter",
    composer: "Mozart",
    date: "2025-10-18",
    time: "19:30",
    location: "Music Hall",
    description: "Welcome guest condutor Dame Jane Glover conducting Moazrt's All-Amadeus program"
  },
  {
    title: "Dame Jane Conducts Mozart",
    program: "Overature to Lucio Silla, Sinfonia Concertante, Symphony No. 41: Jupiter",
    composer: "Mozart",
    date: "2025-10-19",
    time: "14:00",
    location: "Music Hall",
    description: "Welcome guest condutor Dame Jane Glover conducting Moazrt's All-Amadeus program"
  },
  {
    title: "Ingrid Michaelson",
    program: "",
    composer: "Michaelson",
    date: "2025-10-20",
    time: "19:30",
    location: "Music Hall",
    description: "Indie star Ingrid Micahelson performs alongside the Cincinnati Pops at Music Hall"
  },
  {
    title: "Barber & Shostakovich",
    program: "Violin Concerto, Symphony No. 4",
    composer: "Barber, Shostakovich",
    date: "2025-10-24",
    time: "11:00",
    location: "Music Hall",
    description: "Gramophone's Young Artist of the Year Stella Chen joins CSO tugging at the heartstrings"
  },
  {
    title: "Barber & Shostakovich",
    program: "Violin Concerto, Symphony No. 4",
    composer: "Barber, Shostakovich",
    date: "2025-10-25",
    time: "19:30",
    location: "Music Hall",
    description: "Gramophone's Young Artist of the Year Stella Chen joins CSO tugging at the heartstrings"
  },
  {
  title: "Yo-Yo Ma Plays Elgar",
  program: "Tragic Overture, Cello Concerto in E minor",
  composer: "Brahms, Elgar",
  date: "2025-11-04",
  time: "19:30",
  location: "Music Hall",
  description: "Cellist Yo-Yo Ma reunites with Cristian Măcelaru for a one-night-only performance of Elgar’s haunting concerto"
},
{
  title: "Handel's Messiah",
  program: "Messiah (complete)",
  composer: "George Frideric Handel",
  date: "2025-12-13",
  time: "19:30",
  location: "Music Hall",
  description: "A beloved holiday tradition featuring the CSO and May Festival Chorus in Handel’s iconic oratorio"
},
{
  title: "Stravinsky's Firebird",
  program: "Firebird Suite, Violin Concerto",
  composer: "Stravinsky, Prokofiev",
  date: "2026-01-17",
  time: "19:30",
  location: "Music Hall",
  description: "A fiery evening of Russian brilliance with Stravinsky’s ballet masterpiece and Prokofiev’s dazzling concerto"
},
{
  title: "Mozart & Mahler",
  program: "Symphony No. 41 'Jupiter', Symphony No. 4",
  composer: "Mozart, Mahler",
  date: "2026-02-08",
  time: "14:00",
  location: "Music Hall",
  description: "From Mozart's celestial final symphony to Mahler’s introspective Fourth, this program spans joy and depth"
}

  

  
];
