<!-- base code from copiolit ik i spelled that wrong-->
<script>
  import { journalData } from './stores/journal.js';
  import { get } from 'svelte/store';
  //let playlist = [];
  let today = new Date().toISOString().split('T')[0];
  let entry = get(journalData)[today] || {
    photos: []
  };

  function removeItem(id) {
      entry.photos = entry.photos.filter(photo => photo.id !== id);
  }

  function handleUpload(event) {
    const files = event.target.files;
    for (const file of files) {
      const reader = new FileReader();
      reader.onload = () => {
        entry.photos = [
          ...entry.photos,
          {
            id: crypto.randomUUID(),
            src: reader.result,
            title: '',
            mood: '',
            genre: ''
          }
        ];
      };
      reader.readAsDataURL(file);
    }
  }

  function updatePhoto(id, field, value) {
    entry.photos = entry.photos.map(photo =>
      photo.id === id ? { ...photo, [field]: value } : photo
    );
  }
</script>

<style>
  .gallery {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: 1rem;
  }
  .item {
    position: relative;
    padding: 0;
    border-radius: 8px;
    background: transparent;
    overflow: hidden;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
  }

  .item img {
    display: block;
    width: 100%;
    height: auto;
    border: none;
    border-radius: 8px;
    object-fit: cover;
  }

  .item input {
    margin-top: 0.5rem;
    width: 100%;
    padding: 0.3rem;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 0.9rem;
  }

  .remove {
    position: absolute;
    top: 6px;
    right: 6px;
    background: rgba(255, 255, 255, 0.7);
    color: #333;
    border: none;
    border-radius: 50%;
    width: 22px;
    height: 22px;
    font-size: 1rem;
    cursor: pointer;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    transition: background 0.2s ease;
  }

  .remove:hover {
    background: rgba(255, 255, 255, 0.9);
  }
</style>

<div>
  <input type="file" multiple accept="image/*" on:change={handleUpload} />
</div>

<div class="gallery">
  {#each entry.photos as photo (photo.id)}
    <div class="item">
      <button class="remove" on:click={() => removeItem(photo.id)}>×</button>
      <img src={photo.src} alt="Uploaded image" />
      <input
        type="text"
        placeholder="Add a title or tag"
        bind:value={photo.title}
        on:input={(e) => updatePhoto(photo.id,'title',e.target.value)}
      />
    </div>
  {/each}
</div>
