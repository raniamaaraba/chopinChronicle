// stores/journal.js
import { persisted } from 'svelte-local-storage-store';
// Keyed by ISO date string: 'YYYY-MM-DD'
export const journalData = persisted('journal-data', {});
//https://dev.to/danawoodman/svelte-quick-tip-connect-a-store-to-local-storage-4idi
