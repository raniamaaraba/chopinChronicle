<!-- similarties to https://svelte.dev/playground/5aa7d011c2104b0c8906248f66da22ea?version=5.38.8#H4sIAAAAAAAAE606i27bRra_csBuQumKkkhKtmzadJEm7W2LuAWa4C4WYYAdkUNpNtQMLzm0pAr698W8-JAoJVtsEsTkzHnPec2hDxZFG2wF1luUYZqgwnKslGS4tIJPB4vvc7EnFizHQL7J80n5gjMu1paoxH3rMaMcU15agfVYxgXJ-VNEI042OSs4GGaQFmwDkTWZmhVNIbIeWuCHuMCI4x9fMOXvSJkjHq9x4QCjz6yi_KjI2ArVFpg04i-ogATtf0MbXEIInyLrQ0Ujy4HIemb64WOF1cPfcaJX1pV6-Kkg6uED4pH1WYqTYQ4bRvm6RfRXRCtU7DUSXhbN2zMq4rV6fJMXJDOrevvXimLzlOm1N9WqKrlmjHOON0tcqNffY87ql9_YS2vrHY7122etvJB0jVGCCylmIz5lWwiB4i28QxwPhvXGHqNC7LDtZIX5T1WW_QOjQgDwiE-nEedrUgIpga-xMgK8VkgJKfMM7XHSMVFD61m8tjhhcYwf8Y6HkfU2I_EXQBQIxxtg4sTM4TdHaFSQYnxcY7XGmeEMhAJG8RqWbKcQ04rGnDAKBaLJL5QPNmg3hIPYiniBeVVQeEZ8PUkzxoqBfBSgbDMY_o-AHXlS3KPEoA3n2nHfsk3OKKYc_lWV3EhSQsmrNBUCISjYFl5DzLJqQyfwC4c1KoEy-ELZNsPJCgNLpb7lpM1CWKL89BmWOGNbQAWGPEMxTmCw3MOeVUNFvcxxTFKCkw4fQVIcUGzCyVD-B6uAYpwIs8UoyyAlNPmDbd-ybDDUi7FELdh2GrMMRGQnwLRppVRQclRwKfMEfhTL4lGYXeqGtE9BXrAcF3xfc39DEwdI2hz0Cy4ylJeCWekItlSoVkuIkgQQ-DTR4FRKVlbLEv9_JYxesO3EeIgSzXh5-_QJJcr7fhEgg9oDpL9DKN33oVnaQKh8t7WWeGEdLHtn4xiHWgxHi6GGkwKEn9RLxA-c8AwHkeV5gevCR1R-gR9RkUk_lfQjy4kzVJYijQSRxVH5ZTzOC7JRqUMYNejlejscOhmmgXmfD0fe0TljvAhmLvz9C_ggSJe97LaooISuDLvEOyXs9xD-XZ1bTugKPkhPH5DyB8Y52wS8qPCwRe6cJaEpiyzJZ-508HpYea4w3jMrsOYk4p1dtc5iOPLmw-uM25ZzEswRyX6WeTKIrHckTUlcZSL_qq23qooFkfVDJXInByzjDmXZHkoWWT2Cv8kykaCk6b8mru_1iZsgupKpXQjsOS_iR30axslFYH3UKXm7xgWWAXQWxZxBXnEVw0IUFVGKQMoKGAgnJyJtSC-uQ0R5fxFD2M4UZCJoGL-POElhIGBCoFWWtZAjHjNasgxPMrYa2AlJ6D-5pKRShmBtO6Sh1EU45dPdFem_vUcmMi-9ZRmEoF_-kHXOraGOgLMStwXsYBXxJGbZOU1FpognBds2tNTD0VQIGvG_BSqyHZFSHJF3tOuouifTIMRrxkoM2zVSOXQq3GSFedmU0LqUmcQ6OUtoNWGjTFPnTbtj8pJJf4Ph6YpOiA8tFc6zZsOiVYSbbClA3iyXBX4xeVMy_yQfP0_KjMR44DqzYQuJ4p2i3Yc4kM8jb_jK83vwRSGRHiT8O0Mlh2dGhQl1zcsL_EJYVeocK3FEfUhJUfJ3aN_ue-Qx6SMDbyjalHdoP2hYddw3TUJ7ZMiMbLBHxtKfzOpng2p6ll-oiM5n0wr1MB55Driadd2KtQm8RyW_RuAiurCEQZSQYejC9-B5oN107Blnri1brtlWmlGe9RKnIvPKqitrvrQx0baFQUJKtMxwMoQxoGwrUDJciuYQUVicppfwRJ-xsdoDeTzZeiCj0UkSStrq16qFoed9L4wx9gJpk3rHISOvSQ-C_iSvyvXgIO4pgW2PBgLAwVRqEKQoK7GuWs7RIB4vWYbQjiE0lZYd_DsYw8w7s4FbK1s7xteUlXptznUSaZeEoTuEU-1aQSn9tKuqKLVnmkZcZsav2ukC8kmokNAekZENkHBRmexRMrJlMhsM9XvjsZdsjei-bvFTkmVQ5U3Mi273P3U_90Fql2G64utXi6-ZfbDpONhIOdjQaeenbz2Qk4TXcyj9_vetp3LFe0_zequOJ7zWv8dDtaEumElAfCKfZYXuGECerLo0QhiGkPBmoSmsr19D0roVtiD1yjmovlU0kNp9Gkh9pTsUbBu07nVkKnosJ2ZZQF4tRt6x63AaS7QuDyoVnpVCjjfyijrAtSWa66tdb4M9-vXD779NSl4QuiLpXsCPwIaMxSjjZINDe4SlySacfZBQrerbMEzQ_go_Rt_p_f8aQ9U8XOX5cwumj28PVeH1TfegwmZkepAUBnpCEILntzxMBtuo9ikVhe6pSzdcRMZvuNR0ZRweulS8uuBJLuOxoXrSFqrqOD7jGdHHaTPGoo8JeQHZuIeRZe7aYzHzQoSK1v0pogD9UMqaGgTgce3pJ4DHZcU5o8BoEAtrh4fBMHxSAh-fXr_nD49TBfIVFGWZ49PrrAcFDmfN2hEOgsvxOlV1qsen16tvFkQd6fHp9f-eoTxOpeby7lT7mzT24zQhL08qFB_NxEVD6mZXR_BBJCPzLC8w-oXRwIRSeBjgYfjURNZE3e2GDWgdxxq2FfbnwK1o0OCdGDpBmD4J19H6CDcq-T7DTxGdnLuNcEOALUn4OoB799WDeN2gYkVoAKjiTC6I2UmasW0Aa5IkmMrFJduNyzVKxLILfr4D3813UKyWaOA6oP9NZMkS0EWCi3GBElKVAXhuvlPrKP6yKlhFkwC-S9NUC7Aba5k831Wgx7b8Sn0lPMc7PkYZWdEAYkw5LiSNHCUJoatASeWeM8M4bUu2VKMB8PIdlCwjidLEu711wLu9c8Bb3Et9_OEFadaeEsiYT_FMGeXjkvyJA_DuLmqiPfnwFSmVeF39buVrzDJWBErmO8-Bu1sH7mdC4IU6gLgqSgGRM1LbiFU8IxQrUY8y4WhXUX8txxLWtfTA5MJw_mSO3p3Qn2-2x_R92UqmqYgfvpOXUnPTRKV-VOFa5ojWmAnajwW7yDpJBYke3A_sVrzYjnoZHp90aB8fp4KeYjsVbHVR1jLIxhCV4qcJ_O-ImKPuJ7onOppkfibYFZlMerCdBO2FNIKg0KMtT8QPgagXlzkIOcamO_0vsJuS9Ni1hL60aWuo2Scq5YPefiyxrI9GyEsy1FnOdsTj8AgGwygkxlEg8-qknlIdI8ukfOmfYWStCpKM1fw50OBmtHKEKUgbqeUM0-ODQjZEJLLo29qYf7CtgDMwMqGMS5ylBspMD7-3MU3swFa5xj4-COmUEk_1ZE5iyPFcfXDSZ-R6ewbYnGs7FuRQToHpcNBAa__pcE7jcbr221B5B0hPb46P07wGatWH9pmLDX2U3Who6mPPp7W_9K0M7ySumB2cfTXSe7L974yBWhvdEbx0UAmv-UMIvVKZocVJc3VWIlUq1kOyQLrMQ6tUeq6uldKXON7kGeJYe2QZQIFzjPhg4cCG0A3aDTxRhhzw0mI47EEUHyUCuDFVUW6K8qs3JPZJKdbVWVQTkQUOf7mWNcWZrNb827HahVeiduuSN9ctgVzOMOe4GJc5itWuXm-Xx7npCURnQf6UcLVGu3aZ--7-DrlIVb6clUQ4rDB6hjh5wXL5zzGhCd4F4DVGCkSnzdKxKGODBYURLIYdw2kLuBdQBIY37CyN21SaxHKJqYC-66Hgzc9I-NeEuOmh4XtnNGZXaPh-H427MxrzazTue2jMbs5o3FyhMbvtoTH3z2jcXjvHjuqmLnjTq2fv9-H400t2lzizPpzZ9JKdJc68D2c-vWRXiXPTh3MzvWRHiXPbh3M7vWq3RR_OYrpocGRnpYDaserrWJVJgBeIlikrNgFUeY6LGJW4E674HnlocZY1Wu36X8xcon0dr7EK2zp9SkG39WornOtGSWnU7pq9G1_wcMV_t4LHzfDk0jA26qTyz-ku2aAVDqAqsoFozDgK5Mq0fFmNdpvMeTV7W76sVAUJ7blrgxJcPb8QvP2B7ULbBRfm4p8Nu01Gy9Bec54H0-l2u51sZxNWrKa-67qCrv1q9uOr2duVnFmG9it_libpfZracmHMRLbl-9D29EJRZTi0xdWXJYlGzhFfQxLaz4Ln-7kL7s---94F332WYvyf7773pTxThTBd6Z_li3iKrO4FgzJxvhnb4kTZPaIT1dW1zjnDKTdXvJk-tbpy3OW7xsHMbaq5MbYoyLIdKE-5WE4uFIh2h1c7YsRN3fDl2-m19aa-wXU-aZ_rVrtKspzPk56rLk7dZNkJkjS-X3puS-kxZ3kA41Oe6lvtFZbo1l3gh_PUZhrj2UN0ViW6PLWeXZlllPg3Mwe8-4UDvnvXvl4a5nf-zRx35BWfwi9LO1_c3dbX_m-SwLtzwJ95Dvg3Nz0SuOgGS4KNBPr3HHqu1y3u5obt9s4rjDPVeroGrj0FEU6qGh8p6sJzwJvNa0nnw7ZYqjtXQjU-ipYlyyqOddeUciORNIv42D4QzafoI_LdaYYSqTbFZwODa5nU71rP03p1xidf68ouGavHOPO-GZF7N-z2bP65nQKUcnGp6Kzpb4bauXTpMK25Mt5Mvxl7KFvIipWjAlOu1Ve_dQGRBfJ3wQBMVXHbfb_7cOW09GhlLEeLpciEFPco0hW6VfbGnXJ04aA0hpbnrpMlx0rl8V03Y7QNeIVtPX7rsrjtZXHbxwLW_nmncHOSyN1uI-_d3N4kPaTy9jBN5YR5z52hWybq_qE1e-v2AV-dlMmC1R2Edcdgnx1LCLglNLHUt7DjvwHfhJSt0ioAAA-->
<script>
  import * as cso from './cso.js';
  import * as lso from './lso.js';
  import * as kyso from './kyso.js';
  import { journalData } from './stores/journal.js';
  import { get } from 'svelte/store';
  let { today, saveEntry, selectedOrch } = $props();

  //switch for orchestras
  let orchestraEvents = $derived(() => {
    if(selectedOrch === 'CSO') return cso.csoEvents;
    if(selectedOrch === 'LSO') return lso.lsoEvents;
    if(selectedOrch === 'KYSO') return kyso.kysoEvents;
    return[];
  });

  let currentDate = $state(new Date());
  let dateIndex = $derived(() => currentDate.toISOString().split('T')[0]); //use for indexing
  
  let entry = $state(get(journalData)[dateIndex()] ?? {
      decade: '',
      genre: '',
      notes: '',
      photos: [],
      calendarEvents: [],
      userEvents: []
    }
  );

  //fix the issues with the rune versions
  //let userEvents = $derived(() => entry.userEvents ?? []);
  let allEvents = $derived(() => [...(orchestraEvents() ?? []), ...(entry.userEvents ?? [])]);  let month = $derived(() => currentDate.getMonth());
  let year = $derived(() => currentDate.getFullYear());

  /*
  function addUserEvent(event) {
    userEvents = [...userEvents, event];
  }
  */

  function changeMonth(offset) {
    saveEntry();
    currentDate.setMonth(currentDate.getMonth() + offset);
    currentDate = new Date(currentDate);
    today = currentDate;
  }

  //accurately get no of days
  function getDaysInMonth(month, year) {
    return new Date(year, month + 1, 0).getDate();
  }

  //sim
  function getStartDay(month, year) {
    return new Date(year, month, 1).getDay(); // index 0 sunday
  }

  //more rune fixes
  let days = $derived(() =>
  Array(getStartDay(month(), year())).fill(null)
    .concat(Array.from({ length: getDaysInMonth(month(), year()) }, (_, i) => i + 1))
  );

  //auto-save when entry changes
  $effect(() => {
    journalData.update(data => {
      data[dateIndex] = entry;
      return data;
    });
  });

  //<!-- make sure that the user can add their own events-->
  /*
  let newEvent = $state({
    title: '',
    program: '',
    composer: '',
    date: '',
    time: '',
    location: '',
    description: '',
  });
  removing since cannot get to sync
  


  function submitEvent() {
    if (newEvent.title && newEvent.date) {
      // Convert to local midnight and ISO string
      const rawDate = new Date(newEvent.date);
      const localMidnight = new Date(
        rawDate.getFullYear(),
        rawDate.getMonth(),
        rawDate.getDate()
      );
      const isoDate = localMidnight.toISOString().split('T')[0]; // 'YYYY-MM-DD'

      entry.userEvents = [
        ...entry.userEvents,
        {
          id: crypto.randomUUID(),
          title: newEvent.title,
          program: newEvent.program,
          composer: newEvent.composer,
          date: isoDate, // store as string
          time: newEvent.time,
          location: newEvent.location,
          description: newEvent.description
        }
      ];

      newEvent = {
        title: '',
        program: '',
        composer: '',
        date: '',
        time: '',
        location: '',
        description: ''
      };
    }
  }
    */




  //sync features to save with app

  function changeDay(offset) {
    saveEntry(); //save current entry before switching
    currentDate.setDate(currentDate.getDate() + offset);
    currentDate = new Date(currentDate);
    today = currentDate; //update parent
  }
  

</script>

<!-- redp ;ole tje odl one-->
<div class="calendar">
  <div class="header">
    <button onclick={() => changeMonth(-1)}>← Prev</button>
    <h2>{currentDate.toLocaleString('default', { month: 'long' })} {year()}</h2>
    <button onclick={() => changeMonth(1)}>Next →</button>
  </div>

  <div class="grid">
    {#each ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'] as dayName}
      <div><strong>{dayName}</strong></div>
    {/each}

    {#each days() as day}
      <div class="day {day === today.getDate() && month() === today.getMonth() && year() === today.getFullYear() ? 'today' : ''}">
        {#if day}
          <div>{day}</div>
          {#each allEvents().filter(e => {
            const cellDate = new Date(year(), month(), day);
            const cellKey = cellDate.toISOString().split('T')[0];
            return e.date === cellKey;
          }) as event}
            <div class="event">{event.title}</div>
          {/each}
        {/if}
      </div>
    {/each}
  </div>
</div>

<!--
<div class="form">
  <h3>Add Your Own Performance</h3>
  <input type="text" placeholder="Title" bind:value={newEvent.title} />
  <input type="text" placeholder="Program" bind:value={newEvent.program} />
  <input type="text" placeholder="Composer" bind:value={newEvent.composer} />
  <input type="date" bind:value={newEvent.date} />
  <input type="time" bind:value={newEvent.time} />
  <input type="text" placeholder="Location" bind:value={newEvent.location} />
  <textarea placeholder="Description" bind:value={newEvent.description}></textarea>
  <button onclick={submitEvent}>Add Performance</button>
</div>
--->




<style>
  .calendar {
    max-width: 700px;
    margin: auto;
    text-align: center;
    font-family:cursive ;
  }

  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    font-family:cursive ;
  }

  .grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 0.5rem;
  }

  .day {
    border: 1px solid #d6b1c0;
    padding: 0.5rem;
    min-height: 80px;
    position: relative;
    background: #FFF0F5;
    border-radius: 6px;
    font-family: system-ui, Avenir, Helvetica, Arial, sans-serif;
    color: #6f0b33;

  }

  .day.today {
    border: 2px solid #d6b1c0;
    background: #d4c4d0;
    color: white;
  }

  .event {
    font-size: 0.75rem;
    margin-top: 0.3rem;
    background: #c8bbbb;
    padding: 2px 4px;
    border-radius: 4px;
    color: white;
  }

  button {
    padding: 0.3rem 0.6rem;
    background: #ddd6e1;
    border: none;
    cursor: pointer;
    border-radius: 4px;
  }

</style>




